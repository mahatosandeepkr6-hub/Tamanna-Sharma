document.querySelector('.btn').addEventListener('click', () => {
  location.href = 'https://your-domain.com/report-form';
});
